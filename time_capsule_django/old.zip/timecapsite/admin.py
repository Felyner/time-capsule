from django.contrib import admin
from .models import TimeCapsule, TimeCapsuleAsset

# Register your models here.

admin.site.register(TimeCapsule)
admin.site.register(TimeCapsuleAsset)
